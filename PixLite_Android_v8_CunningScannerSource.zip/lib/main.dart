
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:cunning_document_scanner/cunning_document_scanner.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  final prefs = await SharedPreferences.getInstance();
  runApp(PixLiteApp(initialLang: prefs.getString('lang') ?? 'en'));
}

const kBg = Color(0xFF080A14);
const kCard = Color(0xFF121522);
const kCard2 = Color(0xFF181B2B);
const kStroke = Color(0xFF252A3D);
const kText = Color(0xFFF6F7FF);
const kSub = Color(0xFFA6ABC4);
const kViolet = Color(0xFF8B5CFF);
const kBlue = Color(0xFF27D7FF);
const kMint = Color(0xFF37E8B4);
const kGold = Color(0xFFFFC857);
const kPink = Color(0xFFFF5E98);

const langNames = {'en':'English','ar':'العربية','fr':'Français','es':'Español'};

class L {
  static final Map<String, Map<String, String>> s = {
    'en': {
      'tag':'SMART FILE TOOLS','hero':'Make files lighter,\ncleaner and ready.','hero_sub':'Compress, resize, scan, convert and create QR codes with a clean workflow.',
      'services':'Services','compress':'Compress','compress_sub':'Reduce image size','resize':'Resize','resize_sub':'Change dimensions','scan':'Scan','scan_sub':'Clean document photos',
      'pdf':'Image to PDF','pdf_sub':'Create a PDF file','qr':'QR Code','qr_sub':'Generate QR locally','gallery':'Gallery','camera':'Camera','quality':'Quality','process':'Process',
      'save_share':'Save / Share','width':'Width','height':'Height','keep_ratio':'Keep ratio','create_pdf':'Create PDF','generate_qr':'Generate QR','text_link':'Text or link',
      'ad':'Advertisement','after_result_ad':'Ad after result','before':'Before','after':'After'
    },
    'ar': {
      'tag':'أدوات ملفات ذكية','hero':'خلّي ملفاتك أخف،\nأنظف وجاهزة.','hero_sub':'ضغط، تغيير أبعاد، مسح وثائق، تحويل PDF وإنشاء QR بتجربة بسيطة.',
      'services':'الخدمات','compress':'ضغط الصور','compress_sub':'تقليل حجم الصورة','resize':'تغيير الأبعاد','resize_sub':'تعديل العرض والطول','scan':'مسح المستند','scan_sub':'تنظيف صور الوثائق',
      'pdf':'صورة إلى PDF','pdf_sub':'إنشاء ملف PDF','qr':'رمز QR','qr_sub':'إنشاء QR محليًا','gallery':'المعرض','camera':'الكاميرا','quality':'الجودة','process':'معالجة',
      'save_share':'حفظ / مشاركة','width':'العرض','height':'الطول','keep_ratio':'الحفاظ على النسبة','create_pdf':'إنشاء PDF','generate_qr':'إنشاء QR','text_link':'نص أو رابط',
      'ad':'إعلان','after_result_ad':'إعلان بعد النتيجة','before':'قبل','after':'بعد'
    },
    'fr': {
      'tag':'OUTILS DE FICHIERS','hero':'Rends tes fichiers\nplus légers et prêts.','hero_sub':'Compresser, redimensionner, scanner, convertir en PDF et créer un QR.',
      'services':'Services','compress':'Compresser','compress_sub':'Réduire la taille','resize':'Redimensionner','resize_sub':'Changer les dimensions','scan':'Scanner','scan_sub':'Nettoyer les documents',
      'pdf':'Image en PDF','pdf_sub':'Créer un fichier PDF','qr':'Code QR','qr_sub':'Créer un QR local','gallery':'Galerie','camera':'Caméra','quality':'Qualité','process':'Traiter',
      'save_share':'Enregistrer / Partager','width':'Largeur','height':'Hauteur','keep_ratio':'Garder le ratio','create_pdf':'Créer PDF','generate_qr':'Créer QR','text_link':'Texte ou lien',
      'ad':'Publicité','after_result_ad':'Pub après résultat','before':'Avant','after':'Après'
    },
    'es': {
      'tag':'HERRAMIENTAS SMART','hero':'Archivos más ligeros,\nlimpios y listos.','hero_sub':'Comprime, redimensiona, escanea, convierte a PDF y crea QR.',
      'services':'Servicios','compress':'Comprimir','compress_sub':'Reducir tamaño','resize':'Redimensionar','resize_sub':'Cambiar dimensiones','scan':'Escanear','scan_sub':'Limpiar documentos',
      'pdf':'Imagen a PDF','pdf_sub':'Crear PDF','qr':'Código QR','qr_sub':'Crear QR local','gallery':'Galería','camera':'Cámara','quality':'Calidad','process':'Procesar',
      'save_share':'Guardar / Compartir','width':'Ancho','height':'Alto','keep_ratio':'Mantener ratio','create_pdf':'Crear PDF','generate_qr':'Crear QR','text_link':'Texto o enlace',
      'ad':'Anuncio','after_result_ad':'Anuncio después','before':'Antes','after':'Después'
    }
  };
}

class PixLiteApp extends StatefulWidget {
  final String initialLang;
  const PixLiteApp({super.key, required this.initialLang});
  @override State<PixLiteApp> createState() => _PixLiteAppState();
}

class _PixLiteAppState extends State<PixLiteApp> {
  late String lang;
  @override void initState(){ super.initState(); lang = widget.initialLang; }
  Future<void> setLang(String v) async { final p = await SharedPreferences.getInstance(); await p.setString('lang', v); setState(() => lang = v); }
  String tr(String k) => L.s[lang]?[k] ?? L.s['en']![k] ?? k;
  @override Widget build(BuildContext context) {
    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: MaterialApp(
        title:'PixLite', debugShowCheckedModeBanner:false,
        theme: ThemeData(
          useMaterial3:true, scaffoldBackgroundColor:kBg, colorScheme: ColorScheme.fromSeed(seedColor:kViolet, brightness:Brightness.dark),
          appBarTheme: const AppBarTheme(backgroundColor:kBg, surfaceTintColor:Colors.transparent, foregroundColor:kText),
          filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor:kViolet, foregroundColor:Colors.white, minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)))),
          outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(foregroundColor:kText, side: const BorderSide(color:kStroke), minimumSize: const Size.fromHeight(48), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)))),
          inputDecorationTheme: InputDecorationTheme(filled:true, fillColor:kCard2, labelStyle: const TextStyle(color:kSub), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color:kStroke)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color:kStroke)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color:kViolet))),
        ),
        home: HomeScreen(lang: lang, tr: tr, onLang: setLang),
      ),
    );
  }
}

class AdIds {
  static String get banner => Platform.isAndroid ? 'ca-app-pub-3940256099942544/6300978111' : 'ca-app-pub-3940256099942544/2934735716';
}

class BannerAdBox extends StatefulWidget {
  final String label; const BannerAdBox({super.key, required this.label});
  @override State<BannerAdBox> createState()=>_BannerAdBoxState();
}
class _BannerAdBoxState extends State<BannerAdBox> {
  BannerAd? ad; bool loaded=false;
  @override void initState(){ super.initState(); ad=BannerAd(size:AdSize.banner, adUnitId:AdIds.banner, listener:BannerAdListener(onAdLoaded:(_){ if(mounted)setState(()=>loaded=true); }, onAdFailedToLoad:(ad,e)=>ad.dispose()), request: const AdRequest())..load(); }
  @override void dispose(){ ad?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return Container(height:60, alignment:Alignment.center, decoration:BoxDecoration(color:kCard, border:Border.all(color:kStroke), borderRadius:BorderRadius.circular(20)),
      child: loaded && ad!=null ? SizedBox(width:ad!.size.width.toDouble(), height:ad!.size.height.toDouble(), child:AdWidget(ad:ad!)) : Text(widget.label.toUpperCase(), style: const TextStyle(fontSize:10, letterSpacing:1, color:kSub)));
  }
}

class HomeScreen extends StatelessWidget {
  final String lang; final String Function(String) tr; final Future<void> Function(String) onLang;
  const HomeScreen({super.key, required this.lang, required this.tr, required this.onLang});
  void open(BuildContext c, Widget p)=>Navigator.push(c, MaterialPageRoute(builder:(_)=>p));
  @override Widget build(BuildContext context) {
    final tools=[
      ToolData(tr('compress'),tr('compress_sub'),Icons.compress_rounded,kViolet,CompressScreen(tr:tr)),
      ToolData(tr('resize'),tr('resize_sub'),Icons.photo_size_select_large_rounded,kMint,ResizeScreen(tr:tr)),
      ToolData(tr('scan'),tr('scan_sub'),Icons.document_scanner_rounded,kBlue,ScanScreen(tr:tr)),
      ToolData(tr('pdf'),tr('pdf_sub'),Icons.picture_as_pdf_rounded,kGold,ImageToPdfScreen(tr:tr)),
      ToolData(tr('qr'),tr('qr_sub'),Icons.qr_code_2_rounded,kPink,QrScreen(tr:tr)),
    ];
    return Scaffold(body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(18,14,18,26), children:[
      Row(children:[
        ClipRRect(borderRadius:BorderRadius.circular(18), child: Image.asset('assets/pixlite_icon.png', width:48, height:48, fit:BoxFit.cover)),
        const SizedBox(width:12),
        const Expanded(child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Text('PixLite', style:TextStyle(color:kText,fontSize:24,fontWeight:FontWeight.w900,letterSpacing:-.7)), SizedBox(height:2), Text('Premium mobile tools', style:TextStyle(color:kSub,fontSize:11))])),
        PopupMenuButton<String>(initialValue:lang, color:kCard2, icon:Container(padding: const EdgeInsets.all(10), decoration:BoxDecoration(color:kCard,borderRadius:BorderRadius.circular(16),border:Border.all(color:kStroke)), child: const Icon(Icons.language_rounded,color:kText,size:20)), onSelected:onLang, itemBuilder:(_)=>langNames.entries.map((e)=>PopupMenuItem(value:e.key, child:Text(e.value))).toList()),
      ]),
      const SizedBox(height:18),
      Container(padding: const EdgeInsets.all(22), decoration:BoxDecoration(borderRadius:BorderRadius.circular(30), border:Border.all(color: const Color(0x3337E8B4)), gradient: const LinearGradient(colors:[Color(0xFF111429),Color(0xFF1B1740),Color(0xFF101E32)],begin:Alignment.topLeft,end:Alignment.bottomRight), boxShadow: const [BoxShadow(color:Color(0x66000000),blurRadius:28,offset:Offset(0,16))]),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Text(tr('tag'), style: const TextStyle(color:kMint,fontSize:10,letterSpacing:1.6,fontWeight:FontWeight.w800)),
          const SizedBox(height:12), Text(tr('hero'), style: const TextStyle(color:kText,height:1.05,fontSize:31,fontWeight:FontWeight.w900,letterSpacing:-1)),
          const SizedBox(height:12), Text(tr('hero_sub'), style: const TextStyle(color:kSub,fontSize:12.5,height:1.55)),
          const SizedBox(height:18), const Row(children:[MiniPill('Fast',kBlue),SizedBox(width:8),MiniPill('Private',kMint),SizedBox(width:8),MiniPill('Lite',kViolet)])
        ])),
      const SizedBox(height:14), BannerAdBox(label:tr('ad')),
      const SizedBox(height:22), Text(tr('services'), style: const TextStyle(color:kText,fontSize:18,fontWeight:FontWeight.w900)),
      const SizedBox(height:12),
      GridView.builder(itemCount:tools.length, shrinkWrap:true, physics: const NeverScrollableScrollPhysics(), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:.97), itemBuilder:(context,i){
        final t=tools[i]; return InkWell(borderRadius:BorderRadius.circular(26), onTap:()=>open(context,t.page), child:Container(padding: const EdgeInsets.all(15), decoration:BoxDecoration(color:kCard,border:Border.all(color:kStroke),borderRadius:BorderRadius.circular(26),boxShadow:[BoxShadow(color:t.color.withOpacity(.12),blurRadius:18,offset: const Offset(0,8))]), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Row(children:[Container(width:50,height:50,decoration:BoxDecoration(color:t.color.withOpacity(.13),borderRadius:BorderRadius.circular(18),border:Border.all(color:t.color.withOpacity(.35))), child:Icon(t.icon,color:t.color,size:27)), const Spacer(), Container(width:30,height:30,decoration:BoxDecoration(color:t.color.withOpacity(.14),shape:BoxShape.circle), child:Icon(Icons.arrow_forward_rounded,color:t.color,size:17))]),
          const Spacer(), Text(t.title,maxLines:1,overflow:TextOverflow.ellipsis,style: const TextStyle(color:kText,fontSize:14,fontWeight:FontWeight.w900)), const SizedBox(height:5), Text(t.subtitle,maxLines:2,overflow:TextOverflow.ellipsis,style: const TextStyle(color:kSub,fontSize:10.5,height:1.35)),
        ]))); }),
      const SizedBox(height:18), BannerAdBox(label:tr('ad')),
    ])));
  }
}
class MiniPill extends StatelessWidget{ final String text; final Color color; const MiniPill(this.text,this.color,{super.key}); @override Widget build(BuildContext context)=>Container(padding: const EdgeInsets.symmetric(horizontal:11,vertical:7), decoration:BoxDecoration(color:color.withOpacity(.12),borderRadius:BorderRadius.circular(99),border:Border.all(color:color.withOpacity(.35))), child:Text(text,style:TextStyle(color:color,fontSize:10,fontWeight:FontWeight.w900))); }
class ToolData { final String title,subtitle; final IconData icon; final Color color; final Widget page; const ToolData(this.title,this.subtitle,this.icon,this.color,this.page); }

class ToolShell extends StatelessWidget { final String title; final Widget child; const ToolShell({super.key, required this.title, required this.child}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title,style: const TextStyle(fontWeight:FontWeight.w900))), body:SafeArea(child:ListView(padding: const EdgeInsets.fromLTRB(18,8,18,26),children:[child]))); }
class CardBox extends StatelessWidget{ final Widget child; const CardBox({super.key, required this.child}); @override Widget build(BuildContext context)=>Container(padding: const EdgeInsets.all(15), decoration:BoxDecoration(color:kCard,border:Border.all(color:kStroke),borderRadius:BorderRadius.circular(24)), child:child); }

abstract class ImageToolState<T extends StatefulWidget> extends State<T> {
  final picker=ImagePicker(); Uint8List? input; Uint8List? output; bool busy=false;
  Future<void> choose(ImageSource source) async { try{ final file=await picker.pickImage(source:source,imageQuality:100); if(file==null)return; final bytes=await file.readAsBytes(); setState((){input=bytes; output=null;}); } catch(_){ showMsg('Could not open image'); } }
  Future<void> shareBytes(Uint8List bytes,String name) async { final dir=await getTemporaryDirectory(); final file=File('${dir.path}/$name'); await file.writeAsBytes(bytes,flush:true); await Share.shareXFiles([XFile(file.path)]); }
  void showMsg(String msg){ if(!mounted)return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(msg))); }
}
class PickerPanel extends StatelessWidget { final String Function(String) tr; final Uint8List? bytes; final VoidCallback gallery,camera; const PickerPanel({super.key,required this.tr,this.bytes,required this.gallery,required this.camera}); @override Widget build(BuildContext context)=>CardBox(child:Column(children:[
  Container(height:260,width:double.infinity,decoration:BoxDecoration(color:kCard2,borderRadius:BorderRadius.circular(20),border:Border.all(color:kStroke)),clipBehavior:Clip.antiAlias,child:bytes==null?const Center(child:Icon(Icons.image_outlined,size:54,color:kSub)):Image.memory(bytes!,fit:BoxFit.contain)),
  const SizedBox(height:12), Row(children:[Expanded(child:OutlinedButton.icon(onPressed:gallery,icon: const Icon(Icons.photo_library_outlined),label:Text(tr('gallery')))), const SizedBox(width:8), Expanded(child:OutlinedButton.icon(onPressed:camera,icon: const Icon(Icons.photo_camera_outlined),label:Text(tr('camera'))))])
])); }
class ResultAd extends StatelessWidget { final bool show; final String label; const ResultAd({super.key,required this.show,required this.label}); @override Widget build(BuildContext context)=>show?Padding(padding: const EdgeInsets.only(top:14),child:BannerAdBox(label:label)): const SizedBox.shrink(); }

class CompressScreen extends StatefulWidget { final String Function(String) tr; const CompressScreen({super.key,required this.tr}); @override State<CompressScreen> createState()=>_CompressScreenState(); }
class _CompressScreenState extends ImageToolState<CompressScreen>{ double quality=.82; Future<void> process() async{ final data=input; if(data==null)return; setState(()=>busy=true); try{ final decoded=img.decodeImage(data); if(decoded==null)throw Exception(); final result=Uint8List.fromList(img.encodeJpg(decoded,quality:(quality*100).round())); setState(()=>output=result);}catch(_){showMsg('Processing failed');}finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext context)=>ToolShell(title:widget.tr('compress'), child:Column(children:[PickerPanel(tr:widget.tr,bytes:output??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)), if(input!=null)...[const SizedBox(height:12), CardBox(child:Column(children:[Row(children:[Text(widget.tr('quality'),style: const TextStyle(color:kText,fontWeight:FontWeight.w800)),const Spacer(),Text('${(quality*100).round()}%',style: const TextStyle(color:kSub))]), Slider(value:quality,min:.25,max:1,activeColor:kViolet,onChanged:(v)=>setState(()=>quality=v)), if(output!=null)Padding(padding: const EdgeInsets.only(bottom:8), child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('${widget.tr('before')} ${(input!.length/1024).round()} KB',style: const TextStyle(fontSize:11,color:kSub)), Text('${widget.tr('after')} ${(output!.length/1024).round()} KB',style: const TextStyle(fontSize:11,fontWeight:FontWeight.w900,color:kMint))])), FilledButton(onPressed:busy?null:process,child:Text(busy?'...':widget.tr('process'))), if(output!=null)OutlinedButton(onPressed:()=>shareBytes(output!,'pixlite-compressed.jpg'),child:Text(widget.tr('save_share')))])), ResultAd(show:output!=null,label:widget.tr('after_result_ad'))]]));
}

class ResizeScreen extends StatefulWidget{ final String Function(String) tr; const ResizeScreen({super.key,required this.tr}); @override State<ResizeScreen> createState()=>_ResizeScreenState(); }
class _ResizeScreenState extends ImageToolState<ResizeScreen>{ final w=TextEditingController(); final h=TextEditingController(); double ratio=1; bool keepRatio=true; @override void dispose(){w.dispose();h.dispose();super.dispose();}
  @override Future<void> choose(ImageSource source) async{ await super.choose(source); final d=img.decodeImage(input??Uint8List(0)); if(d!=null){ ratio=d.width/d.height; w.text=d.width.toString(); h.text=d.height.toString(); setState((){}); } }
  void syncHeight(String value){ if(!keepRatio||ratio==0)return; final width=int.tryParse(value); if(width==null||width<1)return; h.text=(width/ratio).round().toString(); }
  Future<void> process() async{ final data=input; if(data==null)return; setState(()=>busy=true); try{ final decoded=img.decodeImage(data); if(decoded==null)throw Exception(); final nw=(int.tryParse(w.text)??decoded.width).clamp(1,10000); final nh=(int.tryParse(h.text)??decoded.height).clamp(1,10000); final resized=img.copyResize(decoded,width:nw,height:nh,interpolation:img.Interpolation.average); setState(()=>output=Uint8List.fromList(img.encodeJpg(resized,quality:92))); }catch(_){showMsg('Resize failed');}finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext context)=>ToolShell(title:widget.tr('resize'), child:Column(children:[PickerPanel(tr:widget.tr,bytes:output??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)), if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[Row(children:[Expanded(child:TextField(controller:w,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:widget.tr('width')),onChanged:syncHeight)),const SizedBox(width:8),Expanded(child:TextField(controller:h,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:widget.tr('height'))))]), const SizedBox(height:8), SwitchListTile(contentPadding:EdgeInsets.zero,value:keepRatio,activeColor:kMint,onChanged:(v)=>setState(()=>keepRatio=v),title:Text(widget.tr('keep_ratio'),style: const TextStyle(color:kText,fontWeight:FontWeight.w700))), FilledButton(onPressed:busy?null:process,child:Text(busy?'...':widget.tr('process'))), if(output!=null)OutlinedButton(onPressed:()=>shareBytes(output!,'pixlite-resized.jpg'),child:Text(widget.tr('save_share')))])), ResultAd(show:output!=null,label:widget.tr('after_result_ad'))]]));
}





class ScanScreen extends StatefulWidget{
  final String Function(String) tr;
  const ScanScreen({super.key,required this.tr});
  @override State<ScanScreen> createState()=>_ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen>{
  final List<String> scannedPaths = [];
  String? pdfPath;
  bool busy=false;
  bool pdfBusy=false;

  bool get hasResult => scannedPaths.isNotEmpty || pdfPath != null;

  Future<void> scanImages() async{
    setState(()=>busy=true);
    try{
      final pictures = await CunningDocumentScanner.getPictures(
        noOfPages: 5,
        scannerSource: ScannerSource.cameraAndGallery,
        androidScannerMode: AndroidScannerMode.full,
      );

      if(pictures != null && pictures.isNotEmpty){
        setState((){
          scannedPaths
            ..clear()
            ..addAll(pictures);
          pdfPath = null;
        });
      }else{
        if(mounted){
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content:Text('No scan returned. Try again with better light.'))
          );
        }
      }
    } on CunningDocumentScannerException catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('Scanner error: ${e.message}'))
        );
      }
    } catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('Scanner failed: $e'))
        );
      }
    } finally{
      if(mounted)setState(()=>busy=false);
    }
  }

  Future<void> scanPdf() async{
    setState(()=>pdfBusy=true);
    try{
      final docs = await CunningDocumentScanner.getPictures(
        noOfPages: 5,
        asPdf: true,
        scannerSource: ScannerSource.cameraAndGallery,
        androidScannerMode: AndroidScannerMode.full,
      );

      if(docs != null && docs.isNotEmpty){
        setState((){
          pdfPath = docs.first;
          scannedPaths.clear();
        });
      }else{
        if(mounted){
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content:Text('No PDF returned. Try again.'))
          );
        }
      }
    } on CunningDocumentScannerException catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('Scanner error: ${e.message}'))
        );
      }
    } catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('PDF scan failed: $e'))
        );
      }
    } finally{
      if(mounted)setState(()=>pdfBusy=false);
    }
  }

  Future<void> shareScan() async{
    if(scannedPaths.isNotEmpty){
      await Share.shareXFiles(scannedPaths.map((p)=>XFile(p)).toList());
      return;
    }

    if(pdfPath != null){
      await Share.shareXFiles([XFile(pdfPath!)]);
    }
  }

  Future<void> clearCache() async{
    try{
      await CunningDocumentScanner.cleanCache();
    }catch(_){}
    setState((){
      scannedPaths.clear();
      pdfPath = null;
    });
  }

  @override Widget build(BuildContext context)=>ToolShell(
    title:widget.tr('scan'),
    child:Column(children:[
      CardBox(child:Column(children:[
        Container(
          height:310,
          width:double.infinity,
          decoration:BoxDecoration(
            color:kCard2,
            borderRadius:BorderRadius.circular(22),
            border:Border.all(color:kStroke)
          ),
          clipBehavior:Clip.antiAlias,
          child:scannedPaths.isNotEmpty
            ? PageView(
                children: scannedPaths.map((p)=>Image.file(File(p),fit:BoxFit.contain)).toList(),
              )
            : pdfPath!=null
              ? Column(
                  mainAxisAlignment:MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.picture_as_pdf_rounded,size:76,color:kGold),
                    SizedBox(height:14),
                    Text('Scanned PDF ready',style:TextStyle(color:kText,fontSize:18,fontWeight:FontWeight.w900)),
                    SizedBox(height:8),
                    Padding(
                      padding:EdgeInsets.symmetric(horizontal:22),
                      child:Text(
                        'Your scanned document was generated as a PDF file.',
                        textAlign:TextAlign.center,
                        style:TextStyle(color:kSub,fontSize:12,height:1.45)
                      ),
                    ),
                  ],
                )
              : Column(
                  mainAxisAlignment:MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.document_scanner_rounded,size:76,color:kBlue),
                    SizedBox(height:14),
                    Text('Document scanner',style:TextStyle(color:kText,fontSize:18,fontWeight:FontWeight.w900)),
                    SizedBox(height:8),
                    Padding(
                      padding:EdgeInsets.symmetric(horizontal:22),
                      child:Text(
                        'Scan from camera or import from gallery. Crop and filters are handled by the scanner.',
                        textAlign:TextAlign.center,
                        style:TextStyle(color:kSub,fontSize:12,height:1.45)
                      ),
                    ),
                  ],
                ),
        ),
        if(scannedPaths.length>1)...[
          const SizedBox(height:8),
          Text('${scannedPaths.length} scanned pages',style: const TextStyle(color:kMint,fontSize:12,fontWeight:FontWeight.w900)),
        ],
        const SizedBox(height:16),
        FilledButton.icon(
          onPressed:busy?null:scanImages,
          icon:Icon(busy?Icons.hourglass_empty_rounded:Icons.document_scanner_rounded),
          label:Text(busy?'Opening scanner...':'Scan / Import document')
        ),
        const SizedBox(height:10),
        OutlinedButton.icon(
          onPressed:pdfBusy?null:scanPdf,
          icon:Icon(pdfBusy?Icons.hourglass_empty_rounded:Icons.picture_as_pdf_rounded),
          label:Text(pdfBusy?'Creating PDF...':'Scan as PDF')
        ),
        if(hasResult)...[
          const SizedBox(height:10),
          OutlinedButton.icon(
            onPressed:shareScan,
            icon: const Icon(Icons.ios_share_rounded),
            label:Text(widget.tr('save_share'))
          ),
          const SizedBox(height:10),
          OutlinedButton.icon(
            onPressed:clearCache,
            icon: const Icon(Icons.delete_outline_rounded),
            label: const Text('Clear scan')
          )
        ]
      ])),
      ResultAd(show:hasResult,label:widget.tr('after_result_ad'))
    ])
  );
}

class ImageToPdfScreen extends StatefulWidget{ final String Function(String) tr; const ImageToPdfScreen({super.key,required this.tr}); @override State<ImageToPdfScreen> createState()=>_ImageToPdfScreenState(); }
class _ImageToPdfScreenState extends ImageToolState<ImageToPdfScreen>{ Future<void> process() async{ final data=input; if(data==null)return; setState(()=>busy=true); try{ final doc=pw.Document(); final mem=pw.MemoryImage(data); doc.addPage(pw.Page(build:(_)=>pw.Center(child:pw.Image(mem,fit:pw.BoxFit.contain)))); final pdfBytes = await doc.save(); setState(()=>output=Uint8List.fromList(pdfBytes)); }catch(_){showMsg('PDF failed');}finally{if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext context)=>ToolShell(title:widget.tr('pdf'), child:Column(children:[PickerPanel(tr:widget.tr,bytes:input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)), if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[FilledButton(onPressed:busy?null:process,child:Text(busy?'...':widget.tr('create_pdf'))), if(output!=null)OutlinedButton(onPressed:()=>shareBytes(output!,'pixlite.pdf'),child:Text(widget.tr('save_share')))])), ResultAd(show:output!=null,label:widget.tr('after_result_ad'))]]));
}

class QrScreen extends StatefulWidget{ final String Function(String) tr; const QrScreen({super.key,required this.tr}); @override State<QrScreen> createState()=>_QrScreenState(); }
class _QrScreenState extends State<QrScreen>{ final ctrl=TextEditingController(); final qrKey=GlobalKey(); String value=''; @override void dispose(){ctrl.dispose(); super.dispose();}
  Future<void> shareQr() async{ try{ final boundary=qrKey.currentContext?.findRenderObject() as RenderRepaintBoundary?; if(boundary==null)return; final image=await boundary.toImage(pixelRatio:3); final data=await image.toByteData(format:ui.ImageByteFormat.png); if(data==null)return; final dir=await getTemporaryDirectory(); final file=File('${dir.path}/pixlite-qr.png'); await file.writeAsBytes(data.buffer.asUint8List(),flush:true); await Share.shareXFiles([XFile(file.path)]); }catch(_){} }
  @override Widget build(BuildContext context)=>ToolShell(title:widget.tr('qr'), child:Column(children:[CardBox(child:Column(children:[TextField(controller:ctrl,decoration:InputDecoration(labelText:widget.tr('text_link'))), const SizedBox(height:14), FilledButton(onPressed:()=>setState(()=>value=ctrl.text.trim()),child:Text(widget.tr('generate_qr'))), if(value.isNotEmpty)...[const SizedBox(height:22), RepaintBoundary(key:qrKey,child:Container(padding: const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)), child:QrImageView(data:value,version:QrVersions.auto,size:220))), const SizedBox(height:12), OutlinedButton(onPressed:shareQr,child:Text(widget.tr('save_share')))] ])), ResultAd(show:value.isNotEmpty,label:widget.tr('after_result_ad'))]));
}
