# PixLite Android v8 CunningScannerSource

Scanner is rebuilt using `cunning_document_scanner`:
- Scan / Import document
- Camera + Gallery source
- AndroidScannerMode.full
- Scan as PDF
- Multi-page up to 5 pages
- Share scans or PDF
