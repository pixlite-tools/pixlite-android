# PixLite Android v6 MLKitScannerSource

This build replaces the old manual Scan feature with a real Android document scanner based on Google ML Kit Document Scanner.

Includes:
- Premium dark interface
- Selected app icon
- Language selector: English / Arabic / French / Spanish
- Two home banner ad positions
- Banner ad after successful service result
- No interstitial ads in this test build
- Compress, Resize, real Android Document Scanner, Image to PDF, QR Code
- Fast startup: ads initialize without blocking UI

Scanner note:
- Android only for now.
- Uses native ML Kit document scanner UI from Google Play services.
- Can auto capture, crop, apply filters and return a document image.
