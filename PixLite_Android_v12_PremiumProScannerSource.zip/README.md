# PixLite Android v12 – Premium Pro Scanner

Merged release candidate:
- Premium Night UI from v10
- 3 Home ad placements
- Home / Files / Settings
- Cunning Document Scanner camera + gallery + crop
- OpenCV Pro processing: Clean HD, Text HD, B&W Pro, Color HD
- 10-page scanning
- Fast native splash prepared by workflow
- App starts UI before AdMob initialization to avoid white startup stalls
- Test AdMob IDs only
