# PixLite Android v7 FullScannerSource

This version changes Scan to full ML Kit document scanner mode.

Changes:
- ScannerMode.full instead of ScannerMode.filter
- JPEG + PDF result formats
- Page limit 3
- Gallery import disabled so scanning starts as a real camera scanner flow
- Result preview + PDF ready note
- Existing premium UI, language selector, ads, Compress, Resize, Image to PDF and QR are preserved.
