# PixLite Android v11 – Pro Scanner

- Cunning Scanner capture + auto crop + gallery import.
- OpenCV native post-processing at original scan resolution.
- Automatic Clean HD after capture.
- Clean HD, Text HD, B&W Pro, Color HD.
- CLAHE local contrast, bilateral/NLM denoise, adaptive threshold and controlled sharpening.
- Up to 10 pages.
- Original comparison and Save/Share.
