# PixLite v14 Scanbot Proof of Quality

- scanbot_sdk 9.0.1
- Ready-To-Use DocumentScanningFlow
- JPEG quality 100
- No ads
- No OpenCV
- No ML Kit
- No Cunning scanner
- Initialization after first Flutter frame
- Evaluation without license: about 60 seconds per app session
