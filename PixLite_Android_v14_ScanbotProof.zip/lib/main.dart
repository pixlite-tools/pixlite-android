import 'package:flutter/material.dart';
import 'package:scanbot_sdk/scanbot_sdk.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PixLiteScanbotProof());
}

class PixLiteScanbotProof extends StatefulWidget {
  const PixLiteScanbotProof({super.key});

  @override
  State<PixLiteScanbotProof> createState() => _PixLiteScanbotProofState();
}

class _PixLiteScanbotProofState extends State<PixLiteScanbotProof> {
  bool initializing = true;
  bool ready = false;
  bool scanning = false;
  String status = 'Preparing professional scanner…';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => initializeScanbot());
  }

  Future<void> initializeScanbot() async {
    try {
      final config = SdkConfiguration(
        storageImageFormat: StorageImageFormat.JPG,
        storageImageQuality: 100,
      );
      await ScanbotSdk.initialize(config);

      if (!mounted) return;
      setState(() {
        initializing = false;
        ready = true;
        status = 'Scanner ready';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        initializing = false;
        ready = false;
        status = 'Initialization failed: $e';
      });
    }
  }

  Future<void> startScanner() async {
    if (!ready || scanning) return;

    setState(() {
      scanning = true;
      status = 'Scanner opened';
    });

    try {
      final configuration = DocumentScanningFlow();
      final result = await ScanbotSdk.document.startScanner(configuration);

      if (!mounted) return;

      switch (result) {
        case Ok():
          setState(() {
            status = 'Scan completed. Judge the quality in the Scanbot review screen.';
          });
        case Error():
          setState(() {
            status = 'Scanbot error: ${result.error.message}';
          });
        case Cancel():
          setState(() {
            status = 'Scan cancelled';
          });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        status = 'Scanner failed: $e';
      });
    } finally {
      if (mounted) {
        setState(() => scanning = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050814),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7A3CFF),
          brightness: Brightness.dark,
        ),
      ),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                const Spacer(),
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x447A3CFF),
                        blurRadius: 34,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset(
                    'assets/pixlite_icon.png',
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.high,
                  ),
                ),
                const SizedBox(height: 22),
                const Text(
                  'PixLite',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -1,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'Scanbot Quality Test',
                  style: TextStyle(
                    fontSize: 15,
                    color: Color(0xFFB8C0D9),
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Scanner only. No ads, no OpenCV, no ML Kit, no extra processing.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF8D97B4),
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 28),
                if (initializing)
                  const CircularProgressIndicator()
                else
                  SizedBox(
                    width: double.infinity,
                    height: 58,
                    child: FilledButton.icon(
                      onPressed: ready && !scanning ? startScanner : null,
                      icon: Icon(
                        scanning
                            ? Icons.hourglass_top_rounded
                            : Icons.document_scanner_rounded,
                      ),
                      label: Text(
                        scanning ? 'Scanner open…' : 'Start Scanbot Scanner',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 18),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0D1324),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF26304C)),
                  ),
                  child: Text(
                    status,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFFC8D0E6),
                      fontSize: 12,
                      height: 1.4,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Evaluation mode: about 60 seconds per app session without a license.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF69738F),
                    fontSize: 10,
                  ),
                ),
                const Spacer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
