
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/analytics_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  await AnalyticsService.init();

  final prefs = await SharedPreferences.getInstance();
  final saved = prefs.getString('language');
  final device = PlatformDispatcher.instance.locale.languageCode.toLowerCase();
  final initial = saved ?? (['en','fr','es','ar'].contains(device) ? device : 'en');

  runApp(PixLiteApp(initialLanguage: initial));
}

class PixLiteApp extends StatefulWidget {
  final String initialLanguage;
  const PixLiteApp({super.key, required this.initialLanguage});

  @override
  State<PixLiteApp> createState() => _PixLiteAppState();
}

class _PixLiteAppState extends State<PixLiteApp> {
  late String _lang;

  @override
  void initState() {
    super.initState();
    _lang = widget.initialLanguage;
  }

  Future<void> setLanguage(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', code);
    setState(() => _lang = code);
  }

  @override
  Widget build(BuildContext context) {
    final rtl = _lang == 'ar';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PixLite',
      locale: Locale(_lang),
      builder: (context, child) => Directionality(
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF6F7FB),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5B5CF0),
          brightness: Brightness.light,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFFAFBFD),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE6E9F0)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE6E9F0)),
          ),
        ),
      ),
      home: HomeScreen(lang: _lang, onLanguageChanged: setLanguage),
    );
  }
}
