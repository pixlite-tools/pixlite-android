
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../services/localization.dart';
import '../services/ad_service.dart';
import '../services/analytics_service.dart';
import '../widgets/common.dart';
import '../widgets/ad_banner.dart';

abstract class BaseImageState<T extends StatefulWidget> extends State<T> {
  final picker=ImagePicker();
  Uint8List? input;

  Future<void> choose(ImageSource src) async {
    final f=await picker.pickImage(source:src,imageQuality:100);
    if(f==null)return;
    final b=await f.readAsBytes();
    setState(()=>input=b);
  }

  Future<File> temp(Uint8List b,String name) async {
    final d=await getTemporaryDirectory();
    final f=File('${d.path}/$name');
    await f.writeAsBytes(b,flush:true);
    return f;
  }

  Future<void> share(Uint8List b,String name) async {
    final f=await temp(b,name);
    await Share.shareXFiles([XFile(f.path)]);
  }
}

class PickerBlock extends StatelessWidget {
  final String lang; final Uint8List? bytes; final VoidCallback gallery,camera;
  const PickerBlock({super.key,required this.lang,this.bytes,required this.gallery,required this.camera});
  @override Widget build(BuildContext context)=>CardBox(child:Column(children:[
    PreviewBox(bytes:bytes),const SizedBox(height:12),
    Row(children:[
      Expanded(child:OutlinedButton.icon(onPressed:gallery,icon:const Icon(Icons.photo_library_outlined),label:Text(L.t(lang,'gallery')))),
      const SizedBox(width:8),
      Expanded(child:OutlinedButton.icon(onPressed:camera,icon:const Icon(Icons.photo_camera_outlined),label:Text(L.t(lang,'camera')))),
    ])
  ]));
}

class Shell extends StatelessWidget {
  final String title;final Widget child;
  const Shell({super.key,required this.title,required this.child});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w800)),surfaceTintColor:Colors.transparent),
    body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(18,8,18,28),children:[child])),
  );
}

class CompressScreen extends StatefulWidget {final String lang;const CompressScreen({super.key,required this.lang});@override State<CompressScreen>createState()=>_CompressState();}
class _CompressState extends BaseImageState<CompressScreen> {
  double quality=.8;Uint8List? out;
  Future<void> run()async{
    final d=img.decodeImage(input??Uint8List(0));if(d==null)return;
    out=Uint8List.fromList(img.encodeJpg(d,quality:(quality*100).round()));
    setState((){});await AnalyticsService.conversionCompleted('compress');
  }
  @override Widget build(BuildContext context)=>Shell(title:L.t(widget.lang,'compress'),child:Column(children:[
    PickerBlock(lang:widget.lang,bytes:out??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),
    if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[
      Row(children:[Text(L.t(widget.lang,'quality')),const Spacer(),Text('${(quality*100).round()}%')]),
      Slider(value:quality,min:.25,max:1,onChanged:(v)=>setState(()=>quality=v)),
      if(out!=null)Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        Text('${L.t(widget.lang,'before')}: ${(input!.length/1024).round()} KB',style:const TextStyle(fontSize:10)),
        Text('${L.t(widget.lang,'after')}: ${(out!.length/1024).round()} KB',style:const TextStyle(fontSize:10,fontWeight:FontWeight.w700)),
      ]),
      const SizedBox(height:8),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:run,child:Text(L.t(widget.lang,'process')))),
      if(out!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()async{AdService.maybeShowInterstitial();await share(out!,'pixlite-compressed.jpg');},child:Text(L.t(widget.lang,'save')))),
    ]))],
    const SizedBox(height:14),const AdaptiveBannerBox()
  ]));
}

class ResizeScreen extends StatefulWidget {final String lang;const ResizeScreen({super.key,required this.lang});@override State<ResizeScreen>createState()=>_ResizeState();}
class _ResizeState extends BaseImageState<ResizeScreen> {
  final w=TextEditingController(),h=TextEditingController();Uint8List? out;double ratio=1;bool lock=true;bool internal=false;
  @override Future<void> choose(ImageSource s)async{await super.choose(s);final d=img.decodeImage(input??Uint8List(0));if(d!=null){ratio=d.width/d.height;w.text='${d.width}';h.text='${d.height}';setState((){});}}
  @override void dispose(){w.dispose();h.dispose();super.dispose();}
  void widthChanged(String v){if(!lock||internal)return;final n=int.tryParse(v);if(n==null)return;internal=true;h.text='${(n/ratio).round()}';internal=false;}
  void heightChanged(String v){if(!lock||internal)return;final n=int.tryParse(v);if(n==null)return;internal=true;w.text='${(n*ratio).round()}';internal=false;}
  Future<void> run()async{final d=img.decodeImage(input??Uint8List(0));if(d==null)return;final rw=int.tryParse(w.text)??d.width,rh=int.tryParse(h.text)??d.height;final r=img.copyResize(d,width:rw,height:rh);out=Uint8List.fromList(img.encodeJpg(r,quality:92));setState((){});await AnalyticsService.conversionCompleted('resize');}
  @override Widget build(BuildContext context)=>Shell(title:L.t(widget.lang,'resize'),child:Column(children:[
    PickerBlock(lang:widget.lang,bytes:out??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),
    if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[
      Row(children:[Expanded(child:TextField(controller:w,onChanged:widthChanged,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:L.t(widget.lang,'width')))),const SizedBox(width:8),Expanded(child:TextField(controller:h,onChanged:heightChanged,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:L.t(widget.lang,'height'))))]),
      SwitchListTile(contentPadding:EdgeInsets.zero,value:lock,onChanged:(v)=>setState(()=>lock=v),title:const Text('Keep aspect ratio',style:TextStyle(fontSize:11))),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:run,child:Text(L.t(widget.lang,'process')))),
      if(out!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()async{AdService.maybeShowInterstitial();await share(out!,'pixlite-resized.jpg');},child:Text(L.t(widget.lang,'save')))),
    ]))],
    const SizedBox(height:14),const AdaptiveBannerBox()
  ]));
}

class ScanScreen extends StatefulWidget {final String lang;const ScanScreen({super.key,required this.lang});@override State<ScanScreen>createState()=>_ScanState();}
class _ScanState extends BaseImageState<ScanScreen> {
  Uint8List? out;String mode='bw';double contrast=1.3;
  Future<void> run()async{
    final d=img.decodeImage(input??Uint8List(0));if(d==null)return;
    img.Image r=d.clone();
    if(mode!='color')r=img.grayscale(r);
    r=img.adjustColor(r,contrast:contrast);
    if(mode=='bw'){
      for(final p in r){
        final l=img.getLuminance(p);
        final v=l>150?255:0;
        p.r=v;
        p.g=v;
        p.b=v;
      }
    }
    out=Uint8List.fromList(img.encodeJpg(r,quality:94));setState((){});await AnalyticsService.conversionCompleted('scan');
  }
  @override Widget build(BuildContext context)=>Shell(title:L.t(widget.lang,'scan'),child:Column(children:[
    PickerBlock(lang:widget.lang,bytes:out??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),
    if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[
      Row(children:[Text(L.t(widget.lang,'mode')),const Spacer(),DropdownButton<String>(value:mode,items:[
        DropdownMenuItem(value:'bw',child:Text(L.t(widget.lang,'bw'))),
        DropdownMenuItem(value:'gray',child:Text(L.t(widget.lang,'gray'))),
        DropdownMenuItem(value:'color',child:Text(L.t(widget.lang,'color'))),
      ],onChanged:(v)=>setState(()=>mode=v??'bw'))]),
      Row(children:[Text(L.t(widget.lang,'contrast')),Expanded(child:Slider(value:contrast,min:.8,max:1.8,onChanged:(v)=>setState(()=>contrast=v)))]),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:run,child:Text(L.t(widget.lang,'process')))),
      if(out!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()async{AdService.maybeShowInterstitial();await share(out!,'pixlite-scan.jpg');},child:Text(L.t(widget.lang,'save')))),
    ]))],
    const SizedBox(height:14),const AdaptiveBannerBox()
  ]));
}

class ImageToPdfScreen extends StatefulWidget {final String lang;const ImageToPdfScreen({super.key,required this.lang});@override State<ImageToPdfScreen>createState()=>_PdfState();}
class _PdfState extends BaseImageState<ImageToPdfScreen> {
  Future<void> create()async{
    if(input==null)return;
    final doc=pw.Document(),mem=pw.MemoryImage(input!);
    doc.addPage(pw.Page(build:(_)=>pw.Center(child:pw.Image(mem,fit:pw.BoxFit.contain))));
    final bytes=Uint8List.fromList(await doc.save());
    await AnalyticsService.conversionCompleted('image_to_pdf');
    AdService.maybeShowInterstitial();
    await share(bytes,'pixlite.pdf');
  }
  @override Widget build(BuildContext context)=>Shell(title:L.t(widget.lang,'pdf'),child:Column(children:[
    PickerBlock(lang:widget.lang,bytes:input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),
    if(input!=null)...[const SizedBox(height:12),CardBox(child:SizedBox(width:double.infinity,child:FilledButton(onPressed:create,child:Text(L.t(widget.lang,'create')))))],
    const SizedBox(height:14),const AdaptiveBannerBox()
  ]));
}
