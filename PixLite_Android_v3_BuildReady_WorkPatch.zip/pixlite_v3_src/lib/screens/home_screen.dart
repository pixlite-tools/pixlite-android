
import 'package:flutter/material.dart';
import '../services/localization.dart';
import '../services/analytics_service.dart';
import '../widgets/ad_banner.dart';
import 'image_tools.dart';
import 'qr_screen.dart';

class HomeScreen extends StatelessWidget {
  final String lang;
  final ValueChanged<String> onLanguageChanged;
  const HomeScreen({super.key, required this.lang, required this.onLanguageChanged});

  void open(BuildContext context, String tool, Widget page) {
    AnalyticsService.toolOpened(tool);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final tools = [
      ('compress', Icons.compress_rounded, const Color(0xFFEDEBFF), CompressScreen(lang: lang)),
      ('resize', Icons.photo_size_select_large_rounded, const Color(0xFFE7F9F5), ResizeScreen(lang: lang)),
      ('scan', Icons.document_scanner_rounded, const Color(0xFFFFEEF3), ScanScreen(lang: lang)),
      ('pdf', Icons.picture_as_pdf_rounded, const Color(0xFFFFF6E5), ImageToPdfScreen(lang: lang)),
      ('qr', Icons.qr_code_2_rounded, const Color(0xFFEDF5FF), QrScreen(lang: lang)),
      ('soon', Icons.layers_rounded, const Color(0xFFF2EDFF), const ComingSoonScreen()),
    ];

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 32),
          children: [
            Row(
              children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF5B5CF0), Color(0xFF8B7FFF)]),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Center(child: Text('P', style: TextStyle(color: Colors.white,fontWeight: FontWeight.w900,fontSize: 20))),
                ),
                const SizedBox(width: 11),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('PixLite', style: TextStyle(fontSize: 20,fontWeight: FontWeight.w800)),
                    Text(L.t(lang,'tagline'), style: const TextStyle(fontSize: 10,color: Color(0xFF747B89))),
                  ],
                )),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.language_rounded),
                  onSelected: onLanguageChanged,
                  itemBuilder: (_) => const [
                    PopupMenuItem(value:'en',child:Text('English')),
                    PopupMenuItem(value:'fr',child:Text('Français')),
                    PopupMenuItem(value:'es',child:Text('Español')),
                    PopupMenuItem(value:'ar',child:Text('العربية')),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF151722),Color(0xFF34315D)]),
                borderRadius: BorderRadius.circular(28),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(L.t(lang,'hero'), style: const TextStyle(color:Colors.white,fontSize:29,fontWeight:FontWeight.w800,height:1.1)),
                const SizedBox(height:10),
                Text(L.t(lang,'sub'), style: const TextStyle(color:Color(0xFFD9DAE7),fontSize:12,height:1.5)),
              ]),
            ),
            const SizedBox(height: 16),
            const AdaptiveBannerBox(),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF8F5),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(children:[
                const Icon(Icons.lock_outline_rounded,color:Color(0xFF159A86)),
                const SizedBox(width:10),
                Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Text(L.t(lang,'privacy'),style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w800)),
                  const SizedBox(height:2),
                  Text(L.t(lang,'privacySub'),style:const TextStyle(fontSize:9.5,color:Color(0xFF5D817A))),
                ])),
              ]),
            ),
            const SizedBox(height: 22),
            Text(L.t(lang,'tools'), style: const TextStyle(fontSize:15,fontWeight:FontWeight.w800)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap:true,
              physics:const NeverScrollableScrollPhysics(),
              itemCount:tools.length,
              gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount:2,childAspectRatio:1.05,crossAxisSpacing:12,mainAxisSpacing:12),
              itemBuilder:(context,i){
                final t=tools[i];
                return InkWell(
                  borderRadius:BorderRadius.circular(22),
                  onTap:()=>open(context,t.$1,t.$4),
                  child:Container(
                    padding:const EdgeInsets.all(15),
                    decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0xFFE6E9F0))),
                    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                      Container(width:44,height:44,decoration:BoxDecoration(color:t.$3,borderRadius:BorderRadius.circular(14)),child:Icon(t.$2,size:22)),
                      const Spacer(),
                      Text(L.t(lang,t.$1),style:const TextStyle(fontSize:12.5,fontWeight:FontWeight.w800)),
                    ]),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class ComingSoonScreen extends StatelessWidget {
  const ComingSoonScreen({super.key});
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('PDF tools')),
    body:const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
      Icon(Icons.construction_rounded,size:48),
      SizedBox(height:12),
      Text('Coming soon',style:TextStyle(fontWeight:FontWeight.w800)),
    ])),
  );
}
