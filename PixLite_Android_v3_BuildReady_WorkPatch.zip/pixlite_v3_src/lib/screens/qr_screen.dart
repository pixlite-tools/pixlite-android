
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../services/localization.dart';
import '../services/analytics_service.dart';
import '../widgets/ad_banner.dart';

class QrScreen extends StatefulWidget {
  final String lang;
  const QrScreen({super.key, required this.lang});
  @override State<QrScreen> createState()=>_QrScreenState();
}

class _QrScreenState extends State<QrScreen> {
  final ctrl=TextEditingController();
  final key=GlobalKey();
  String value='';

  @override void dispose(){ctrl.dispose();super.dispose();}

  Future<void> saveQr() async {
    final boundary=key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if(boundary==null)return;
    final image=await boundary.toImage(pixelRatio:3);
    final data=await image.toByteData(format:ui.ImageByteFormat.png);
    if(data==null)return;
    final bytes=data.buffer.asUint8List();
    final dir=await getTemporaryDirectory();
    final file=File('${dir.path}/pixlite-qr.png');
    await file.writeAsBytes(bytes,flush:true);
    await AnalyticsService.conversionCompleted('qr');
    await Share.shareXFiles([XFile(file.path)]);
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(L.t(widget.lang,'qr'),style:const TextStyle(fontSize:17,fontWeight:FontWeight.w800))),
    body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(18,8,18,28),children:[
      Container(
        padding:const EdgeInsets.all(15),
        decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0xFFE6E9F0))),
        child:Column(children:[
          TextField(controller:ctrl,decoration:InputDecoration(labelText:L.t(widget.lang,'text'))),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>setState(()=>value=ctrl.text.trim()),child:Text(L.t(widget.lang,'generate')))),
          if(value.isNotEmpty)...[
            const SizedBox(height:20),
            RepaintBoundary(
              key:key,
              child:Container(color:Colors.white,padding:const EdgeInsets.all(18),child:QrImageView(data:value,version:QrVersions.auto,size:220)),
            ),
            const SizedBox(height:12),
            SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:saveQr,icon:const Icon(Icons.ios_share_rounded),label:Text(L.t(widget.lang,'save')))),
          ]
        ]),
      ),
      const SizedBox(height:14),const AdaptiveBannerBox()
    ])),
  );
}
