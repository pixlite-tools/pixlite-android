
import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdService {
  // Google official TEST IDs. Replace only after the owner's AdMob account is ready.
  static String get bannerId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/6300978111'
      : 'ca-app-pub-3940256099942544/2934735716';

  static String get interstitialId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/1033173712'
      : 'ca-app-pub-3940256099942544/4411468910';

  static BannerAd createBanner({required void Function() onLoaded}) => BannerAd(
    size: AdSize.banner,
    adUnitId: bannerId,
    listener: BannerAdListener(onAdLoaded: (_) => onLoaded()),
    request: const AdRequest(),
  );

  static Future<void> maybeShowInterstitial() async {
    final prefs = await SharedPreferences.getInstance();
    final count = (prefs.getInt('completed_exports') ?? 0) + 1;
    await prefs.setInt('completed_exports', count);

    // Conservative rule: only every third successful export.
    if (count % 3 != 0) return;

    InterstitialAd.load(
      adUnitId: interstitialId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) => ad.dispose(),
            onAdFailedToShowFullScreenContent: (ad, _) => ad.dispose(),
          );
          ad.show();
        },
        onAdFailedToLoad: (_) {},
      ),
    );
  }
}
