
class L {
  static const data = <String, Map<String, String>>{
    'en': {
      'tagline':'Smart everyday tools','hero':'Do more with your files.',
      'sub':'Fast, private tools for images, documents and QR codes.',
      'tools':'Tools','compress':'Compress image','resize':'Resize image',
      'scan':'Document scan','pdf':'Image to PDF','qr':'QR generator',
      'soon':'PDF tools','gallery':'Gallery','camera':'Camera','save':'Save / Share',
      'quality':'Quality','process':'Process','width':'Width','height':'Height',
      'create':'Create PDF','text':'Text or link','generate':'Generate QR',
      'language':'Language','privacy':'Privacy first','privacySub':'Most processing stays on your device.',
      'before':'Before','after':'After','bw':'B&W','gray':'Gray','color':'Color',
      'mode':'Mode','contrast':'Contrast','coming':'Coming soon','pdfFuture':'Merge & split PDF will follow after launch.'
    },
    'fr': {
      'tagline':'Des outils simples au quotidien','hero':'Faites plus avec vos fichiers.',
      'sub':'Des outils rapides et privés pour images, documents et QR.',
      'tools':'Outils','compress':'Compresser une image','resize':'Redimensionner',
      'scan':'Scanner un document','pdf':'Image vers PDF','qr':'Générateur QR',
      'soon':'Outils PDF','gallery':'Galerie','camera':'Caméra','save':'Enregistrer / Partager',
      'quality':'Qualité','process':'Traiter','width':'Largeur','height':'Hauteur',
      'create':'Créer PDF','text':'Texte ou lien','generate':'Créer QR',
      'language':'Langue','privacy':'Confidentialité d’abord','privacySub':'La plupart des traitements restent sur votre appareil.',
      'before':'Avant','after':'Après','bw':'N&B','gray':'Gris','color':'Couleur',
      'mode':'Mode','contrast':'Contraste','coming':'Bientôt','pdfFuture':'Fusion et division PDF après le lancement.'
    },
    'es': {
      'tagline':'Herramientas simples para cada día','hero':'Haz más con tus archivos.',
      'sub':'Herramientas rápidas y privadas para imágenes, documentos y QR.',
      'tools':'Herramientas','compress':'Comprimir imagen','resize':'Redimensionar',
      'scan':'Escanear documento','pdf':'Imagen a PDF','qr':'Generador QR',
      'soon':'Herramientas PDF','gallery':'Galería','camera':'Cámara','save':'Guardar / Compartir',
      'quality':'Calidad','process':'Procesar','width':'Ancho','height':'Alto',
      'create':'Crear PDF','text':'Texto o enlace','generate':'Crear QR',
      'language':'Idioma','privacy':'Privacidad primero','privacySub':'La mayor parte del procesamiento permanece en tu dispositivo.',
      'before':'Antes','after':'Después','bw':'B/N','gray':'Gris','color':'Color',
      'mode':'Modo','contrast':'Contraste','coming':'Próximamente','pdfFuture':'Unir y dividir PDF llegará después del lanzamiento.'
    },
    'ar': {
      'tagline':'أدوات ذكية للاستخدام اليومي','hero':'أنجز أكثر بملفاتك.',
      'sub':'أدوات سريعة وخاصة للصور والمستندات وQR.',
      'tools':'الأدوات','compress':'ضغط الصور','resize':'تغيير الأبعاد',
      'scan':'مسح المستند','pdf':'صورة إلى PDF','qr':'مولد QR',
      'soon':'أدوات PDF','gallery':'الصور','camera':'الكاميرا','save':'حفظ / مشاركة',
      'quality':'الجودة','process':'تنفيذ','width':'العرض','height':'الارتفاع',
      'create':'إنشاء PDF','text':'نص أو رابط','generate':'إنشاء QR',
      'language':'اللغة','privacy':'الخصوصية أولاً','privacySub':'معظم المعالجة تبقى على جهازك.',
      'before':'قبل','after':'بعد','bw':'أبيض وأسود','gray':'رمادي','color':'ملون',
      'mode':'الوضع','contrast':'التباين','coming':'قريبًا','pdfFuture':'دمج وتقسيم PDF سيضاف بعد الإطلاق.'
    }
  };

  static String t(String lang, String key) =>
      data[lang]?[key] ?? data['en']![key] ?? key;
}
