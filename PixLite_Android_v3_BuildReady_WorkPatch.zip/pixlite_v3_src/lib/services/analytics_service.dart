
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';

class AnalyticsService {
  static FirebaseAnalytics? _analytics;

  // Call only after google-services.json is added to android/app.
  static Future<void> init() async {
    try {
      await Firebase.initializeApp();
      _analytics = FirebaseAnalytics.instance;
    } catch (_) {
      // Firebase config is intentionally optional in this source build.
    }
  }

  static Future<void> toolOpened(String name) async {
    await _analytics?.logEvent(name: 'tool_opened', parameters: {'tool': name});
  }

  static Future<void> conversionCompleted(String tool) async {
    await _analytics?.logEvent(
      name: 'conversion_completed',
      parameters: {'tool': tool},
    );
  }
}
