
import 'dart:typed_data';
import 'package:flutter/material.dart';

class CardBox extends StatelessWidget {
  final Widget child;
  const CardBox({super.key, required this.child});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: const Color(0xFFE6E9F0)),
    ),
    child: child,
  );
}

class PreviewBox extends StatelessWidget {
  final Uint8List? bytes;
  const PreviewBox({super.key, this.bytes});

  @override
  Widget build(BuildContext context) => Container(
    height: 245,
    width: double.infinity,
    decoration: BoxDecoration(
      color: const Color(0xFFF2F4F8),
      borderRadius: BorderRadius.circular(18),
    ),
    clipBehavior: Clip.antiAlias,
    child: bytes == null
        ? const Center(child: Icon(Icons.image_outlined, size: 48, color: Color(0xFF9AA0AD)))
        : Image.memory(bytes!, fit: BoxFit.contain),
  );
}
