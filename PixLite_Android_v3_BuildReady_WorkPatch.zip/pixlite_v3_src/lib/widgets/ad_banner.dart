
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../services/ad_service.dart';

class AdaptiveBannerBox extends StatefulWidget {
  const AdaptiveBannerBox({super.key});

  @override
  State<AdaptiveBannerBox> createState() => _AdaptiveBannerBoxState();
}

class _AdaptiveBannerBoxState extends State<AdaptiveBannerBox> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _ad = AdService.createBanner(onLoaded: () {
      if (mounted) setState(() => _loaded = true);
    })..load();
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _ad == null) {
      return Container(
        height: 58,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE4E7ED)),
        ),
        child: const Center(
          child: Text('AD', style: TextStyle(color: Color(0xFFA0A6B2), fontSize: 10)),
        ),
      );
    }
    return SizedBox(
      width: _ad!.size.width.toDouble(),
      height: _ad!.size.height.toDouble(),
      child: AdWidget(ad: _ad!),
    );
  }
}
