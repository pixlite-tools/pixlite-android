# PixLite — Google Play listing draft

## App name
PixLite

## Short description
Fast, private tools to compress, resize, scan, convert images and create QR codes.

## Full description
PixLite brings essential everyday file tools into one clean mobile app.

• Compress images and reduce file size
• Resize photos to exact dimensions
• Enhance document photos for easier reading
• Convert images to PDF
• Generate QR codes locally
• Share your results in seconds

Designed for speed and simplicity. Most core image processing is performed locally on your device whenever possible.

Languages planned at launch:
English, French, Spanish and Arabic.

## Category
Tools

## Initial monetization
Free with ads.

## Store screenshots to prepare
1. Global home screen
2. Image compression result
3. Document scanner modes
4. Image to PDF
5. QR generator
6. Language switcher / privacy-first card
