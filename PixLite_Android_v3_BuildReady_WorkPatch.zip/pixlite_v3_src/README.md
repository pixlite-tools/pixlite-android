# PixLite Android v3

This is the most complete source package prepared so far for PixLite's Android-first launch.

The product direction is now fixed:
- Android first
- iPhone second
- Global audience
- English/French/Spanish/Arabic at launch
- Free with non-intrusive ads
- Privacy-first local processing where possible

Core launch tools:
1. Image Compress
2. Image Resize
3. Document Scan
4. Image to PDF
5. QR Generator

PDF merge/split is intentionally postponed until after the first launch so the MVP stays stable and focused.

IMPORTANT:
This archive is source code, not an APK. It still needs a Flutter/Android build environment and the owner's AdMob/Firebase/Google Play credentials/config files for production release.
