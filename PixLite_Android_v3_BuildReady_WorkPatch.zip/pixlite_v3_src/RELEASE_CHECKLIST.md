# PixLite Android v3 — release checklist

DONE IN SOURCE
- Mobile-first Flutter architecture
- Global premium UI
- EN / FR / ES / AR + RTL
- Language persistence + device-language default
- Image compression with before/after size
- Resize with optional aspect-ratio lock
- Document scan modes: B&W / Gray / Color + contrast
- Image to PDF
- Local QR generation + PNG share
- Camera/gallery access
- Local output sharing
- AdMob integration with Google TEST IDs
- Banner ads
- Interstitial throttled to every third successful export
- Firebase Analytics scaffold and events
- App icon source
- Splash/icon configuration
- Privacy policy draft
- Play Store listing draft
- Data Safety preparation notes

OWNER-ACCOUNT STEPS STILL REQUIRED
- Create final Firebase Android app and supply google-services.json
- Create AdMob app and real ad-unit IDs
- Confirm unique Android package name
- Provide developer/support email
- Create Google Play Developer account
- Signing key / Play App Signing
- Closed testing and store submission

TECHNICAL BUILD STEP STILL REQUIRED
- Run `flutter create .` in this source folder if Android/iOS scaffolding is incomplete
- Run `flutter pub get`
- Run launcher icon and splash generators
- Build AAB/APK on a machine or cloud runner with Flutter + Android SDK
