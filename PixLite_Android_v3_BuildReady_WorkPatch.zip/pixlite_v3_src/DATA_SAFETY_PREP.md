# Google Play Data Safety — preparation notes

Final answers must match the exact SDK configuration at release.

Likely SDKs:
- Google Mobile Ads / AdMob
- Firebase Analytics

Core user files:
- Photos/images selected by the user: processed locally by PixLite's core tools in the current design.
- QR text: generated locally and must NOT be sent as an analytics parameter.
- Generated PDFs: created locally.

Before Play Console submission:
1. Review current Google Mobile Ads data disclosure requirements.
2. Review Firebase Analytics data disclosure requirements.
3. Confirm whether consent management is required for EEA/UK users.
4. Add a real support email and hosted privacy-policy URL.
5. Re-check every permission in the final AndroidManifest.
