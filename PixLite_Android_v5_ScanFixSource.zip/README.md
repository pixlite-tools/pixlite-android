# PixLite Android v5 PremiumSource

Includes:
- Premium dark interface
- Selected app icon as asset
- Language selector: English / Arabic / French / Spanish
- Two home banner ad positions
- Banner ad after successful service result
- No interstitial ads in this test build
- Compress, Resize, Scan, Image to PDF, QR Code
- Fast startup: ads initialize without blocking UI

Build using the included GitHub Actions workflow.
