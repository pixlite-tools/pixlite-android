# PixLite v13 Stable ML Kit Scanner

Premium Night UI retained. Cunning/OpenCV removed from scan path. Uses google_mlkit_document_scanner 0.5.0 with ScannerMode.full, gallery import, up to 10 pages, JPEG + PDF, and no automatic Dart/OpenCV post-processing.
