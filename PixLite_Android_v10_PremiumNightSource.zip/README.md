# PixLite v10 Premium Night

Approved dark premium home UI, three Home ad slots, Files/Settings tabs, centered Scan shortcut, and the working Cunning scanner from v8. Test AdMob IDs only.
