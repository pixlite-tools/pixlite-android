import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const PixLiteApp());
}

class PixLiteApp extends StatelessWidget {
  const PixLiteApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PixLite',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFFF6F7FB),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B5CF0)),
          appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF6F7FB), surfaceTintColor: Colors.transparent),
        ),
        home: const HomeScreen(),
      );
}

class AdBox extends StatefulWidget {
  final bool visible;
  const AdBox({super.key, this.visible = true});
  @override
  State<AdBox> createState() => _AdBoxState();
}

class _AdBoxState extends State<AdBox> {
  BannerAd? ad; bool loaded = false;
  @override void initState(){super.initState(); if(widget.visible){ad=BannerAd(size:AdSize.banner,adUnitId:'ca-app-pub-3940256099942544/6300978111',listener:BannerAdListener(onAdLoaded:(_){if(mounted)setState(()=>loaded=true);},onAdFailedToLoad:(a,e)=>a.dispose()),request:const AdRequest())..load();}}
  @override void dispose(){ad?.dispose(); super.dispose();}
  @override Widget build(BuildContext context){
    if(!widget.visible) return const SizedBox.shrink();
    if(!loaded||ad==null) return Container(height:62,alignment:Alignment.center,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFFE2E6EF))),child:const Text('Advertisement',style:TextStyle(fontSize:10,color:Color(0xFF9AA0AD))));
    return Center(child:SizedBox(width:ad!.size.width.toDouble(),height:ad!.size.height.toDouble(),child:AdWidget(ad:ad!)));
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context){
    final tools=[
      Tool('Compress','Reduce image size',Icons.compress_rounded,const Color(0xFFEDEBFF),const CompressScreen()),
      Tool('Resize','Change dimensions',Icons.photo_size_select_large_rounded,const Color(0xFFE7F9F5),const ResizeScreen()),
      Tool('Scan','Clean document photo',Icons.document_scanner_rounded,const Color(0xFFFFEEF3),const ScanScreen()),
      Tool('Image to PDF','Create PDF file',Icons.picture_as_pdf_rounded,const Color(0xFFFFF6E5),const PdfScreen()),
      Tool('QR Code','Create QR locally',Icons.qr_code_2_rounded,const Color(0xFFEDF5FF),const QrScreen()),
    ];
    return Scaffold(body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(18,16,18,26),children:[
      Row(children:[Container(width:48,height:48,decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF5B5CF0),Color(0xFF8C7CFF)]),borderRadius:BorderRadius.circular(16)),child:const Center(child:Text('P',style:TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.w900)))),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('PixLite',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('Fast global image tools',style:TextStyle(fontSize:11,color:Color(0xFF747B89)))]))]),
      const SizedBox(height:18),
      Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF11131A),Color(0xFF2D2B5A)]),borderRadius:BorderRadius.circular(30),boxShadow:const [BoxShadow(color:Color(0x18000000),blurRadius:28,offset:Offset(0,14))]),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('PIXEL TO PRACTICAL',style:TextStyle(color:Color(0xFFB7B8C8),fontSize:10,letterSpacing:1.2)),SizedBox(height:10),Text('Do more\nwith your files.',style:TextStyle(color:Colors.white,height:1.05,fontSize:32,fontWeight:FontWeight.w900)),SizedBox(height:10),Text('Compress, resize, scan, convert and create QR codes in seconds.',style:TextStyle(color:Color(0xFFDADBE8),fontSize:12,height:1.55))])),
      const SizedBox(height:14),const AdBox(),const SizedBox(height:22),const Text('Services',style:TextStyle(fontSize:16,fontWeight:FontWeight.w900)),const SizedBox(height:12),
      GridView.builder(itemCount:tools.length,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.03),itemBuilder:(context,i){final t=tools[i];return InkWell(borderRadius:BorderRadius.circular(24),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>t.page)),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFFE6E9F0)),borderRadius:BorderRadius.circular(24),boxShadow:const [BoxShadow(color:Color(0x08000000),blurRadius:16,offset:Offset(0,7))]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(width:48,height:48,decoration:BoxDecoration(color:t.color,borderRadius:BorderRadius.circular(16)),child:Icon(t.icon,color:const Color(0xFF171923),size:24)),const Spacer(),Text(t.title,style:const TextStyle(fontSize:13,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text(t.subtitle,style:const TextStyle(fontSize:10,color:Color(0xFF747B89)))])));}),
      const SizedBox(height:18),const AdBox(),
    ])));
  }
}
class Tool{final String title,subtitle;final IconData icon;final Color color;final Widget page;const Tool(this.title,this.subtitle,this.icon,this.color,this.page);}

class Shell extends StatelessWidget{final String title;final Widget child;const Shell({super.key,required this.title,required this.child});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900))),body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(18,8,18,26),children:[child])));}
class CardBox extends StatelessWidget{final Widget child;const CardBox({super.key,required this.child});@override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFFE6E9F0)),borderRadius:BorderRadius.circular(24)),child:child);}

abstract class ImgState<T extends StatefulWidget> extends State<T>{
  final picker=ImagePicker(); Uint8List? input; Uint8List? output; bool busy=false;
  Future<void> choose(ImageSource s) async{try{final f=await picker.pickImage(source:s,imageQuality:100); if(f==null)return; final b=await f.readAsBytes(); setState((){input=b;output=null;});}catch(_){msg('Could not open image');}}
  Future<void> share(Uint8List b,String name) async{final d=await getTemporaryDirectory();final f=File('${d.path}/$name');await f.writeAsBytes(b,flush:true);await Share.shareXFiles([XFile(f.path)]);}
  void msg(String m){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(m)));}
}

class PickerPanel extends StatelessWidget{final Uint8List? bytes;final VoidCallback gallery,camera;const PickerPanel({super.key,this.bytes,required this.gallery,required this.camera});@override Widget build(BuildContext context)=>CardBox(child:Column(children:[Container(height:248,width:double.infinity,decoration:BoxDecoration(color:const Color(0xFFF1F3F8),borderRadius:BorderRadius.circular(20)),clipBehavior:Clip.antiAlias,child:bytes==null?const Center(child:Icon(Icons.image_outlined,size:52,color:Color(0xFF9AA0AD))):Image.memory(bytes!,fit:BoxFit.contain)),const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:gallery,icon:const Icon(Icons.photo_library_outlined),label:const Text('Gallery'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:camera,icon:const Icon(Icons.photo_camera_outlined),label:const Text('Camera')))]),]));}
class ResultAd extends StatelessWidget{final bool show;const ResultAd({super.key,required this.show});@override Widget build(BuildContext context)=>show?const Padding(padding:EdgeInsets.only(top:14),child:AdBox()):const SizedBox.shrink();}

class CompressScreen extends StatefulWidget{const CompressScreen({super.key});@override State<CompressScreen> createState()=>_CompressState();}
class _CompressState extends ImgState<CompressScreen>{double q=.82;Future<void> process()async{final data=input;if(data==null)return;setState(()=>busy=true);try{final d=img.decodeImage(data);if(d==null)throw Exception();output=Uint8List.fromList(img.encodeJpg(d,quality:(q*100).round()));setState((){});}catch(_){msg('Processing failed');}finally{setState(()=>busy=false);}}@override Widget build(BuildContext context)=>Shell(title:'Compress',child:Column(children:[PickerPanel(bytes:output??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[Row(children:[const Text('Quality',style:TextStyle(fontWeight:FontWeight.w800)),const Spacer(),Text('${(q*100).round()}%')]),Slider(value:q,min:.25,max:1,onChanged:(v)=>setState(()=>q=v)),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:process,child:Text(busy?'Processing...':'Compress'))),if(output!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()=>share(output!,'pixlite-compressed.jpg'),child:const Text('Save / Share')))])),ResultAd(show:output!=null)]]));}

class ResizeScreen extends StatefulWidget{const ResizeScreen({super.key});@override State<ResizeScreen> createState()=>_ResizeState();}
class _ResizeState extends ImgState<ResizeScreen>{final w=TextEditingController(),h=TextEditingController();@override void dispose(){w.dispose();h.dispose();super.dispose();}@override Future<void> choose(ImageSource s)async{await super.choose(s);final d=img.decodeImage(input??Uint8List(0));if(d!=null){w.text='${d.width}';h.text='${d.height}';setState((){});}}Future<void> process()async{final data=input;if(data==null)return;setState(()=>busy=true);try{final d=img.decodeImage(data);if(d==null)throw Exception();final nw=int.tryParse(w.text)??d.width,nh=int.tryParse(h.text)??d.height;final r=img.copyResize(d,width:nw.clamp(1,10000),height:nh.clamp(1,10000));output=Uint8List.fromList(img.encodeJpg(r,quality:92));setState((){});}catch(_){msg('Resize failed');}finally{setState(()=>busy=false);}}@override Widget build(BuildContext context)=>Shell(title:'Resize',child:Column(children:[PickerPanel(bytes:output??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[Row(children:[Expanded(child:TextField(controller:w,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Width'))),const SizedBox(width:8),Expanded(child:TextField(controller:h,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Height')))]),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:process,child:Text(busy?'Processing...':'Resize'))),if(output!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()=>share(output!,'pixlite-resized.jpg'),child:const Text('Save / Share')))])),ResultAd(show:output!=null)]]));}

class ScanScreen extends StatefulWidget{const ScanScreen({super.key});@override State<ScanScreen> createState()=>_ScanState();}
class _ScanState extends ImgState<ScanScreen>{String mode='bw';Future<void> process()async{final data=input;if(data==null)return;setState(()=>busy=true);try{final d=img.decodeImage(data);if(d==null)throw Exception();var r=d.clone();if(mode=='color'){r=img.adjustColor(r,contrast:1.18,saturation:1.05);}else{r=img.grayscale(r);r=img.adjustColor(r,contrast:1.32);if(mode=='bw'){for(final p in r){final l=img.getLuminance(p);final v=l>150?255:0;p..r=v..g=v..b=v;}}}output=Uint8List.fromList(img.encodeJpg(r,quality:94));setState((){});}catch(_){msg('Scan failed');}finally{setState(()=>busy=false);}}@override Widget build(BuildContext context)=>Shell(title:'Scan',child:Column(children:[PickerPanel(bytes:output??input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[SegmentedButton<String>(segments:const [ButtonSegment(value:'bw',label:Text('B&W')),ButtonSegment(value:'gray',label:Text('Gray')),ButtonSegment(value:'color',label:Text('Color'))],selected:{mode},onSelectionChanged:(v)=>setState(()=>mode=v.first)),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:process,child:Text(busy?'Processing...':'Enhance'))),if(output!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()=>share(output!,'pixlite-scan.jpg'),child:const Text('Save / Share')))])),ResultAd(show:output!=null)]]));}

class PdfScreen extends StatefulWidget{const PdfScreen({super.key});@override State<PdfScreen> createState()=>_PdfState();}
class _PdfState extends ImgState<PdfScreen>{Future<void> process()async{final data=input;if(data==null)return;setState(()=>busy=true);try{final doc=pw.Document();doc.addPage(pw.Page(build:(_)=>pw.Center(child:pw.Image(pw.MemoryImage(data),fit:pw.BoxFit.contain))));output=Uint8List.fromList(await doc.save());setState((){});}catch(_){msg('PDF failed');}finally{setState(()=>busy=false);}}@override Widget build(BuildContext context)=>Shell(title:'Image to PDF',child:Column(children:[PickerPanel(bytes:input,gallery:()=>choose(ImageSource.gallery),camera:()=>choose(ImageSource.camera)),if(input!=null)...[const SizedBox(height:12),CardBox(child:Column(children:[SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:process,child:Text(busy?'Processing...':'Create PDF'))),if(output!=null)SizedBox(width:double.infinity,child:OutlinedButton(onPressed:()=>share(output!,'pixlite.pdf'),child:const Text('Save / Share')))])),ResultAd(show:output!=null)]]));}

class QrScreen extends StatefulWidget{const QrScreen({super.key});@override State<QrScreen> createState()=>_QrState();}
class _QrState extends State<QrScreen>{final ctrl=TextEditingController();final key=GlobalKey();String value='';@override void dispose(){ctrl.dispose();super.dispose();}Future<void> shareQr()async{try{final b=key.currentContext?.findRenderObject() as RenderRepaintBoundary?;if(b==null)return;final i=await b.toImage(pixelRatio:3);final d=await i.toByteData(format:ui.ImageByteFormat.png);if(d==null)return;final dir=await getTemporaryDirectory();final f=File('${dir.path}/pixlite-qr.png');await f.writeAsBytes(d.buffer.asUint8List(),flush:true);await Share.shareXFiles([XFile(f.path)]);}catch(_){}}@override Widget build(BuildContext context)=>Shell(title:'QR Code',child:Column(children:[CardBox(child:Column(children:[TextField(controller:ctrl,decoration:const InputDecoration(labelText:'Text or link')),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>setState(()=>value=ctrl.text.trim()),child:const Text('Generate QR'))),if(value.isNotEmpty)...[const SizedBox(height:20),RepaintBoundary(key:key,child:Container(color:Colors.white,padding:const EdgeInsets.all(18),child:QrImageView(data:value,version:QrVersions.auto,size:220))),const SizedBox(height:12),SizedBox(width:double.infinity,child:OutlinedButton(onPressed:shareQr,child:const Text('Save / Share')))] ])),ResultAd(show:value.isNotEmpty)]));}
