# PixLite Android v4 Clean Source

Focused build:
- Faster startup
- Premium global UI
- Two home banner ads
- A small banner after each completed service result
- No interstitial ads in this build
- Stable Compress, Resize, Scan, Image to PDF, QR
- Test AdMob banner ID only
